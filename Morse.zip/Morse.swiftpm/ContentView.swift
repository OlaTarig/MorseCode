import SwiftUI
import AVFoundation

struct MainView: View {
    init() {
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(Color.systemBackground) // Set tab bar background color
        appearance.stackedLayoutAppearance.selected.iconColor = UIColor(Color.primarySystemColor)
        appearance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor: UIColor(Color.primarySystemColor)]
        appearance.stackedLayoutAppearance.normal.iconColor = UIColor(Color.secondaryLabel)
        appearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor(Color.secondaryLabel)]
        
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }
    
    var body: some View {
        TabView {
            ContentView()
                .tabItem {
                    
                    Text("Translator")
                }
            
            CodeView()
                .tabItem {
                    
                    Text("Learn Morse")
                }
        }
        .tint(Color.primarySystemColor) // Ensures selected tab is Deep Brown
    }
}

struct CodeView: View {
    let morseDictionary: [String: String] = [
        "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".",
        "F": "..-.", "G": "--.", "H": "....", "I": "..", "J": ".---",
        "K": "-.-", "L": ".-..", "M": "--", "N": "-.", "O": "---",
        "P": ".--.", "Q": "--.-", "R": ".-.", "S": "...", "T": "-",
        "U": "..-", "V": "...-", "W": ".--", "X": "-..-", "Y": "-.--",
        "Z": "--..", "0": "-----", "1": ".----", "2": "..---",
        "3": "...--", "4": "....-", "5": ".....", "6": "-....",
        "7": "--...", "8": "---..", "9": "----."
    ]
      let morsePlayer = MorseRadioTonePlayer()
    
    var body: some View {
        List(morseDictionary.sorted(by: { $0.key < $1.key }), id: \.key) { letter, code in
            HStack {
                Text(letter)
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color.primarySystemColor) // Deep brown for contrast
                
                Spacer()
                
                Text(code)
                    .foregroundColor(Color.secondaryLabel) // More readable secondary color
                
                Button(action: {
                    playMorseCode(code)
                }) {
                    Image(systemName: "speaker.wave.2.fill")
                        .foregroundColor(Color.primarySystemColor) // Deep brown to match theme
                        .padding(8)
                        .background(Color.secondarySystemBackground.opacity(0.2)) // Light highlight
                        .clipShape(Circle()) // Circular button for aesthetics
                }
            }
            .padding(.vertical, 6)
            .listRowBackground(Color.systemBackground) // Light beige for list row background
        }
    }
          
            func playMorseCode(_ code: String) {
                morsePlayer.enableSpeaker()
                morsePlayer.play(morse: code)
            }
        }
    

struct ContentView: View {
    @State private var languagePair: LanguagePair = .init(
        leftItem: .english,
        rightItem: .morse
    )
    
    @State private var isTranslatable: Bool = false
    @State private var originText: String = ""
    @State private var translation: MorseTranslation?
    
    @FocusState private var isEditing: Bool
    let translator = MorseTranslator()
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .bottom) {
                VStack(spacing: 16.0) {
                    
                    // Language Selection View
                    LanguagePairView(languagePair: self.$languagePair)
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal, 20)
                    
                    VStack(alignment: .trailing) {
                        if self.isTranslatable {
                            Button {
                                withAnimation {
                                    self.originText = ""
                                    self.translation = nil
                                    self.isEditing = false
                                }
                            } label: {
                                Image(systemName: "trash")
                                    .font(.system(size: 24.0))
                                    .foregroundColor(Color.primarySystemColor) // Deep brown color
                            }
                        }
                        
                        VStack(alignment: .leading, spacing: 16.0) {
                            VStack(alignment: .leading) {
                                if self.translation != nil {
                                    Text("From \(self.languagePair.leftItem.rawValue)")
                                        .font(.headline)
                                        .foregroundColor(Color.secondaryLabel)
                                        .transition(.opacity)
                                }
                                
                                // Text Input
                                TextView(
                                    placeholder: "Enter text",
                                    text: self.$originText,
                                    focus: self._isEditing
                                )
                                .padding()
                                .background(Color.systemBackground)
                                .cornerRadius(12)
                                .shadow(radius: 2)
                            }
                            
                            if let translation = translation {
                                Group {
                                    Divider()
                                    
                                    TranslationView(translation: translation)
                                }
                                .transition(.move(edge: .bottom).combined(with: .opacity))
                            }
                        }
                        
                        Spacer()
                    }
                    .padding(24.0)
                    .frame(maxHeight: .infinity)
                    .background(Color.secondarySystemBackground) // Warm orange background
                    .cornerRadius(16.0, corners: [.topLeft, .topRight])
                    .ignoresSafeArea(.all, edges: .bottom)
                }
                
                // Translate Button
                if self.isTranslatable && self.translation == nil {
                    Button {
                        withAnimation {
                            self.translation = self.translator.translate(
                                text: self.originText,
                                languagePair: self.languagePair
                            )
                            
                            self.isEditing = false
                        }
                    } label: {
                        Text("Translate!")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.primarySystemColor) // Deep brown for contrast
                            .foregroundColor(.white)
                            .cornerRadius(8.0)
                            .shadow(radius: 4)
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16.0)
                    .transition(.opacity)
                    .zIndex(1.0)
                }
            }
            .padding(.top, 16.0)
            .navigationTitle("Morse Translator")
            .navigationBarTitleDisplayMode(.inline)
            .background(Color.systemBackground) // Light beige background
        }
        .navigationViewStyle(.stack)
        .onChange(of: self.originText) { text in
            withAnimation {
                self.isTranslatable = !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            }
        }
        .onChange(of: self.isEditing) { isEditing in
            if isEditing {
                withAnimation {
                    self.translation = nil
                }
            }
        }
    }
}
