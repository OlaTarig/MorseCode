//
//  Language.swift
//  Morse
//
//  Created by Tamerlan Satualdypov on 16.04.2022.
//

import Foundation

enum Language: String {
    case english = "English"
    case morse = "Morse"
}
