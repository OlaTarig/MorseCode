//
//  Color.swift
//  Morse
//
//  Created by Tamerlan Satualdypov on 16.04.2022.
//

import SwiftUI
import UIKit

extension Color {
    /// Initializes a Color instance from a hex code string.
    init(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        
        var rgb: UInt64 = 0
        Scanner(string: hexSanitized).scanHexInt64(&rgb)
        
        let red = Double((rgb >> 16) & 0xFF) / 255.0
        let green = Double((rgb >> 8) & 0xFF) / 255.0
        let blue = Double(rgb & 0xFF) / 255.0
        
        self.init(red: red, green: green, blue: blue)
    }
    
    // MARK: - Custom App Colors
    static let systemBackground = Color(hex: "#F5E3C3")   // Light Beige (Background)
    static let secondarySystemBackground = Color(hex: "#D27C2C") // Warm Orange (Secondary)
    static let primarySystemColor = Color(hex: "#924C10")  // Deep Brown (Primary)
    
    // MARK: - Text Colors
    static let label = Color(UIColor.label)
    static let secondaryLabel = Color(UIColor.secondaryLabel)
    static let placeholderText = Color(UIColor.placeholderText)
}
